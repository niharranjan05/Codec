// Entry point for backend server
